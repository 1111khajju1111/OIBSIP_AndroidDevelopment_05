package com.example.stopwatch

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.stopwatch.R

class MainActivity : AppCompatActivity() {

    private lateinit var timerText: TextView
    private lateinit var startButton: Button
    private lateinit var pauseButton: Button
    private lateinit var stopButton: Button

    private var seconds = 0
    private var isRunning = false
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var runnable: Runnable

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        timerText = findViewById(R.id.timerText)
        startButton = findViewById(R.id.startButton)
        pauseButton = findViewById(R.id.pauseButton)
        stopButton = findViewById(R.id.stopButton)

        runnable = object : Runnable {
            override fun run() {
                if (isRunning) {
                    val minutes = seconds / 60
                    val secs = seconds % 60
                    val time = String.format("%02d:%02d", minutes, secs)
                    timerText.text = time
                    seconds++
                    handler.postDelayed(this, 1000)
                }
            }
        }

        startButton.setOnClickListener {
            if (!isRunning) {
                isRunning = true
                handler.post(runnable)
            }
        }

        pauseButton.setOnClickListener {
            isRunning = false
        }

        stopButton.setOnClickListener {
            isRunning = false
            seconds = 0
            timerText.text = "00:00"
        }
    }
}